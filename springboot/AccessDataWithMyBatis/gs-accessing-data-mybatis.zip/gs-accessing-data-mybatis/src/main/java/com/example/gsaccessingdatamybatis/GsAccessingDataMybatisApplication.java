package com.example.gsaccessingdatamybatis;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GsAccessingDataMybatisApplication {

	public static void main(String[] args) {
		SpringApplication.run(GsAccessingDataMybatisApplication.class, args);
	}
}
